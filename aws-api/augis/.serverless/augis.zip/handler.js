const awsSlsExpress = require('aws-serverless-express');
const app = require('./src/index');

const server = awsSlsExpress.createServer(app);

exports.handler = (event, context) => {
  return awsSlsExpress.proxy(server, event, context);
};